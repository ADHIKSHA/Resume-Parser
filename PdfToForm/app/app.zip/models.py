from django.db import models

# Create your models here.
class General(models.Model):
	name=models.CharField(max_length=100)
	email=models.CharField(max_length=100)
	phone=models.CharField(max_length=50)
	address=models.CharField(max_length=200)
	class Meta:
		db_table="General"
		
class Education(models.Model):
	email=models.CharField(max_length=100)
	degree=models.CharField(max_length=100)
	date=models.CharField(max_length=100)
	inst=models.CharField(max_length=50)
	grade=models.CharField(max_length=50)
	class Meta:
		db_table="Education"

class Internship(models.Model):
	email=models.CharField(max_length=100)
	position=models.CharField(max_length=100)
	company=models.CharField(max_length=100)
	date=models.CharField(max_length=50)
	desc=models.CharField(max_length=200)
	class Meta:
		db_table="Internship"

class Project(models.Model):
	email=models.CharField(max_length=100)
	name=models.CharField(max_length=100)
	date=models.CharField(max_length=100)
	link=models.CharField(max_length=50)
	desc=models.CharField(max_length=200)
	class Meta:
		db_table="Project"