from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from app.models import *
from app.forms import *
import re


def MakeForm(text):
	length=len(text)
	dictionary={}
	flag=0
	count=0
	lines=text.splitlines()
	lines = [x for x in lines if x != ''] 
	print(lines)
	dictionary['Name']=lines[0]
	dictionary['Email']=lines[1]
	email=dictionary['Email']
	dictionary['Phone']=lines[2]
	dictionary['Address']=lines[3]
	
	edu={}
	education=[]
	inter={}
	internship=[]
	pro={}
	project=[]
	for line in lines:
		print('line=',line,flag,count)
		if line =="  ":
			flag=0
			count=0

		if flag==1:
				if count==3 :
					edu['Grade']=line
					education.append(edu)
					obj=Education(email=email,degree=edu['Degree'],date=edu['Date'],inst=edu['Institution'],grade=edu['Grade'])
					obj.save()
					edu={}
					count=0
				elif count==2 :
					edu['Institution']=line
					count=3
				elif count==1 :
					edu['Date']=line
					count=2
				elif count==0 :
					edu['Degree']=line
					count=1


		if flag==2:
				if count==3 :
					inter['Description']=line
					internship.append(inter)
					obj=Internship(email=email,position=inter['Position'],company=inter['Company'],date=inter['Date'],desc=inter['Description'])
					obj.save()
					inter={}
					count=0
				elif count==2 :
					inter['Date']=line
					count=3
				elif count==1 :
					inter['Company']=line
					count=2
				elif count==0 :
					inter['Position']=line
					count=1
		if flag==3:
				if count==3 :
					pro['Description']=line
					project.append(pro)
					obj=Project(email=email,name=pro['Name'],date=pro['Date'],link=pro['Link'],desc=pro['Description'])
					obj.save()
					pro={}
					count=0
				elif count==2 :
					pro['Link']=line
					count=3
				elif count==1 :
					pro['Date']=line
					count=2
				elif count==0 :
					pro['Name']=line
					count=1

		if('Education' in line) and flag==0:
			flag=1
			count=0
		if('Internships' in line) and flag==0:
			flag=2
			count=0
		if('Projects' in line) and flag==0:
			flag=3
			count=0
	dictionary['Education']=education
	dictionary['Internships']=internship
	dictionary['Projects']=project
	return dictionary

def handlefile(myfile):
	from pdfminer3.layout import LAParams, LTTextBox
	from pdfminer3.pdfpage import PDFPage
	from pdfminer3.layout import LAParams, LTTextBox
	from pdfminer3.pdfpage import PDFPage
	from pdfminer3.pdfinterp import PDFResourceManager
	from pdfminer3.pdfinterp import PDFPageInterpreter
	from pdfminer3.converter import PDFPageAggregator
	from pdfminer3.converter import TextConverter
	import io

	resource_manager = PDFResourceManager()
	fake_file_handle = io.StringIO()
	converter = TextConverter(resource_manager, fake_file_handle, laparams=LAParams())
	page_interpreter = PDFPageInterpreter(resource_manager, converter)

	with open('app/static/upload/'+myfile.name, 'rb') as fh:

		for page in PDFPage.get_pages(fh,caching=True,check_extractable=True):
			page_interpreter.process_page(page)

		text = fake_file_handle.getvalue()

	converter.close()
	fake_file_handle.close()
	print(text)
	dictionary=MakeForm(text)
	print(dictionary)
	return dictionary

def handle_uploaded_file(f):  
    with open('app/static/upload/'+f.name, 'wb+') as destination:  
        for chunk in f.chunks():  
            destination.write(chunk)  

def start(request):
	if request.method == 'POST':
		student = StudentForm(request.POST, request.FILES)  
		if student.is_valid():  
			handle_uploaded_file(request.FILES['file'])  
			dictionary=handlefile(request.FILES['file'])
			return render(request,'Form.html',{'table':dictionary})
	else:  
		student = StudentForm()  
		return render(request,"index.html",{'form':student})

@csrf_exempt
def save(request):
	if request.method == 'POST':
		name=request.POST.get('Name')
		email=request.POST.get('Email')
		phone=request.POST.get('Phone')
		add=request.POST.get('Address')
		obj=General(name=name,email=email,phone=phone,address=add)
		obj.save()
	return HttpResponse("Saved SuccessFully!")
